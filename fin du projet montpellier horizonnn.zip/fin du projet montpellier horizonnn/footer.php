
<!DOCTYPE html>
<html>
    <head>
        <title>Montpellier Horizon</title>
        <link rel="stylesheet" href="css/footer.css" >
         <meta charset="UTF-8" >
    </head>
    <body style=" background:#01B0F0;">
        
        
          <footer>
    
   
     <div class="lien">
        <p class="paragraphe">Suivez-nous :</p>
         <a href="https://www.facebook.com/Horizon-Montpellier-203986810335252/?modal=admin_todo_tour" onclick="window.open(this.href); return false;">
         <img src="images/imageRcran/facebook.png"width='70' height='50' class='suivez'></a>
          <a href="https://twitter.com/?lang=fr" onclick="window.open(this.href); return false;">
        <img src="images/imageRcran/twitter.jpg" width='70' height='50' class='suivez'></a>
         <a href="https://www.youtube.com/" onclick="window.open(this.href); return false;">
        <img src="images/imageRcran/youtube.png" width='70' height='50' class='suivez' ></a>
    </div>
    
    <div class="lien" style="margin-left:60px;">
        
        <p class="paragraphe">Nos partenaires :</p>
        
        
         <a href="http://www.montpellier.fr/" onclick="window.open(this.href); return false;">
        <img src="images/imageRcran/Ville_de_Montpellier.png" width='100' height='70' class='suivez'> </a>
        
        <a href="http://www.montpellier3m.fr/" onclick="window.open(this.href); return false;"> 
        <img src="images/imageRcran/agglo.jpg" width='100' height='70' class='suivez'> </a>
        
        <a href="http://www.mhscfoot.com/" onclick="window.open(this.href); return false;">
            <img src="images/imageRcran/mhsc.PNG" width='100' height='70' class='suivez'> </a>
    </div>
     <div class="lien" id="information" style="background:url(images/imageRcran/fond.jpg) no-repeat center top; padding-left:20px;margin-top:25px;margin-left:80px;">
        
        <p class="info"><a href="equipe.php" target="header" >l'équipe</a><br></p>
         <p class="info"><a href="association.php" target="header" >Associations</a></p>
         


    </div>
 
   
    
</footer>
    </body>
</html>