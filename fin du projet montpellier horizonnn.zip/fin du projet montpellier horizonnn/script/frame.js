window.onload=function ()
{
   
   <meta HTTP-EQUIV="REFRESH" CONTENT="2; URL=javascript:window.open('header.php','_header');">
       <meta HTTP-EQUIV="REFRESH" CONTENT="2; URL=javascript:window.open('body.php','_body');">
           <meta HTTP-EQUIV="REFRESH" CONTENT="2; URL=javascript:window.open('left.php','_left');">
               <meta HTTP-EQUIV="REFRESH" CONTENT="2; URL=javascript:window.open('right.php','_right');">
                   <meta HTTP-EQUIV="REFRESH" CONTENT="2; URL=javascript:window.open('footer.php','_footer');">
       
 
}