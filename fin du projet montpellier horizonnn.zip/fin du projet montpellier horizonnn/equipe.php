<!DOCTYPE html>
<html>
<head>
    <title>L'equipe</title>
    <link rel="stylesheet" type="text/css" href="l'equipe.css" />
    <meta charset="utf-8">
    <style>
    table {
    margin-left: 400px;
}
table tr {
    text-align: center;
}
.im {
    height: 100px;
    border-radius: 10px;
}
body
            {
               background:url("images/imageRcran/imageMontpellier.jpg")  repeat center; 
               
            }
        table 
        {
            background: rgba(255, 255, 255, 0.6);
            border-radius: 10px;
            border:1px solid blue;
            padding-top: 50px;
            margin-top: 80px;
        }
    </style>
</head>
<body>
     <?php  include "header.php";?>
    <div class="description">
        <table border="0">
             <tr>
                <th><img src="imageequipe/pertubant.png" class="im"></th>
                <th><img src="imageequipe/jamaisalheure.PNG"  class="im"></th>
                <th><img src="imageequipe/Conard.PNG"  class="im"></th>
                <th><img src="imageequipe/salo.jpg"  class="im"></th>
             </tr>
            <p>
             <tr>
                <td>Nita Illyece</td>
                <td>Bourqaiba Aymane</td>
                <td>Barrano Vincent</td>
                <td>Barry Mamadou</td>
             </tr>
            </p>
            <p>
             <tr>
                <td>L3 MIASHS</td>
                <td>L3 MIASHS</td>
                <td>L3 MIASHS</td>
                <td>L3 MIASHS</td>
             </tr>
            </p>
            <p>
             <tr>
                <td>MontpellierHorizon</td>
                <td>MontpellierHorizon</td>
                <td>MontpellierHorizon</td>
                <td>MontpellierHorizon</td>
             </tr>
            </p>
           
        </table>
    </div>
</body>
</html>