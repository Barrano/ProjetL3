<?php
  echo "<link rel='stylesheet' href='menu.css'>";
   echo"<p><div class='menuColor'> <img src='../images/imageRcran/logo.PNG' alt='' width='200' height='100' class='logo'>";
    echo"<ul><li ><li><a href='gerant.php'>boite de nuit</a></li>";
    echo"<li><a href='plage.php' >plage</a></li>";
    echo"<li><a href='restaurant.php'  >rastaurant</a></li>";
    echo"<li style='color:white;'>STATISTIQUES</li></ul></p></div>"; 

?>