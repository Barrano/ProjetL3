<?php
   include "administrateur.php";
?>
<!DOCTYPE html>
<html>
	<head>
		<title>gerant</title>
		<link rel="stylesheet" href="styles/style.css" type="text/css" /> 
		</head>
		
	<body>

	
			   
			 
			   		<div id="chart-container">
			<canvas id="mycanvas"></canvas>
		</div>
		
<div  class="ht">
		<!-- javascript -->
		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/Chart.min.js"></script>
		<script type="text/javascript" src="js/app.js"></script>
       
		<script type="text/javascript" src="js/app.js"></script>
    </div>

	</body>
</html>