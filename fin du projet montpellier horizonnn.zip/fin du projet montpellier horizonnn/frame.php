
<!DOCTYPE html>
<html>
    <head>
        <title>Montpellier Horizon</title>
            <script src="script/frame.js"></script>
        <FRAMESET rows="83%,17%" frameborder="1" framespacing="0" border="0" > 
            <FRAME src="header.php" name="header" ></FRAME>
            <FRAME src="footer.php" name="footer"></FRAME>
        </FRAMESET>
        <link rel='stylesheet' href='css/menuConecte.css'>
    </head>
    <body>
        
    </body>
</html>