<?php
echo "<link rel='stylesheet' href='css/menu.css'>";
echo"<p><div class='menuColor'><ul><li><a href='accueil.php' >Accueil</a></li>";
echo"<li><a href='inscription.php' >Inscription</a></li>";
echo"<li><a href='contact.php' >CONTACTEZ-NOUS</a></li></ul></p></div>";
?>


