<!DOCTYPE html>
<html>
    <head>
        <title>Montpellier Horizon</title>
        <link rel="stylesheet" href="css/acceuil.css" >
    </head>
    <body>
        <?php include "menu.php"; ?>
    
    jdjgkslm
        <p>khgfdmlhjdfm</p>
        <p>khgfdmlhjdfm</p>
        <p>khgfdmlhjdfm</p>
    
    </body>
</html>