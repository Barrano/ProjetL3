<!DOCTYPE html>
<html>
	<head>
		<title>gerant</title>
		<link rel="stylesheet" href="styles/style.css" type="text/css" /> 
		</head>
		
	<body>
	<nav>
	<p class="p1">Information</p>
            <ul>
			
                <ol>Monsieur</ol>
                <ol>Tel</ol>
                <ol>Age</ol>
				<ol>ville</ol>
				<ol>description</ol>
	<ol><TEXTAREA rows="3" name="commentaires"> 
				...
	</TEXTAREA></ol>
            </ul>
			
        </nav>
          <section>
		  <p class="p1">Avis</p>
	    <aside>
         <ol><TEXTAREA rows="3" name="commentaires"> 
				...
	</TEXTAREA></ol>
	    <ol><TEXTAREA rows="3" name="commentaires"> 
				...
	</TEXTAREA></ol>
	    <ol><TEXTAREA rows="3" name="commentaires"> 
				...
	</TEXTAREA></ol>
	    <ol><TEXTAREA rows="3" name="commentaires"> 
				...
	</TEXTAREA></ol>
            </aside>
            
			   </section>
			   
			   
			   <div class="historique">
			   <p class="p1">Historique</p>
			   
			   <ol><a href="#">Annonce1:</a></ol>
               <ol><a href="#">Annonce2:</a></ol>
               <ol><a href="#">Annonce3:</a></ol>
			  
			
			   </div>
			   
			 
			   		<div id="chart-container">
			<canvas id="mycanvas"></canvas>
		</div>
		

		<!-- javascript -->
		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/Chart.min.js"></script>
		<script type="text/javascript" src="js/app.js"></script>
		</div>
	</body>
</html>