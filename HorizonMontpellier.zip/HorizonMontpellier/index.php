<!DOCTYPE html>

<html>
<head>
<meta charset="UTF-8"/>
<link rel="stylesheet" href="styles/style.css" type="text/css" />
<meta charset="utf-8" />
<title>Accueil</title>

</head>
<body>

<p><img class="p1" src="images/logo.png"></p>
<p><img class="p2" src="images/accueil.png"></p>

<div class="button">
<div class="right">
<ul id="niv1">

<li><a href="inscription/inscription.html" >Inscription</a></li>
<li><a href="" >Login</a></li>
</ul>

</div>
<p class="p3">Vivre c'est aider un autre &agrave vivre</p>
<p class="p4">Vous proposez ou vous <br>cherchez de l'aide,<br> &eacutev&eacutenement ou sport &agrave<br> Montpellier? On est l&agrave pour<br>vous</p>

</div>

<div id="menu">
<ul>
<li><a href="x" >Sport</a>
<ul>
<li><a href="x" >Art martiaux</a></li>
<li><a href="x" >Foot</a></li>
<li><a href="x" >Cyclisme</a></li>
</ul>
</ul>

<ul>
<li><a href="x" >Ev&eacutenement</a>
<ul>
<li><a href="x" >Rondonn&eacutee</a>
<li><a href="x" >Sorties animeaux </a></li>
<li><a href="x" >Trouve ta moiti&eacute</a></li>
<ul>

</li>
</ul>
</div>

<div id="Recommendations1">
<p><img class="p5" src="images/slider4.jpg"></p>

<div>
<p class="p6">Vous cherchez du sport</p>
</div>
</div>
<div id="Recommendations2">
<p><img class="p5" src="images/slider3.jpg"></p>
<div>
<p class="p6">Vous cherchez des conseils</p>
</div>
</div>
</div>

</body>
</html>